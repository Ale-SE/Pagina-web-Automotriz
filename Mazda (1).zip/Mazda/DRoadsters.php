<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pagina Principal</title>
        <style>
            *{
                padding: 0; 
                margin: 0;
                box-sizing: border-box;
            }
            /*Encabezado*/
            header{
                width: 100%;
                background-color: #000;
                color: white;
                padding: 1%;
                text-align: center;
                font-size: 22px;
                display: flex; /* Flexbox para alinear elementos */
                align-items: center;
                justify-content: space-between; /* Espacio entre los elementos */
                position: relative; /* Para el diseño del logo */
            }
            .logo {
                width: auto; /* Mantén el ancho proporcional al alto */
                height: 80px; /* Incrementa la altura para que sea más visible */
                margin-left: 20px; /* Espaciado desde el borde izquierdo */
                position: static; /* Alineado automáticamente en el diseño flex */
            }
            header img {
                max-height: 80px; /* Permite que el logo sea más alto */
                object-fit: contain; /* Asegura que no se distorsione */
            }

            .sesion {
                display: flex;
                align-items: center;  
                position: absolute; /* Posición absoluta para ubicarlo en relación al encabezado */
                right: 40px; /* Lo coloca en el extremo derecho */
                top: 69px; /* Centrado vertical */
                transform: translateY(-50%); /* Ajuste del centrado vertical */  
            }
            .sesion a{
                text-decoration: none;
                color: white;
                font-size: 16px;
                background-color: rgb(182, 57, 57);
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                transition: background-color 0.3s;
                font-weight: bold;
            }
            .sesion a:hover{
                background-color: grey;
                cursor: pointer;
            }
            .modelo{
                text-align: center;
                font-size: 29px;
                font-family: 'Perpetua', sans-serif;
                color: black;
                margin-top: 15px;
                border-bottom: 2px solid #000;  /* Línea debajo de la clase modelo */
                max-width: 80%; /* Limitar el ancho */
                margin-left: auto; /* Centrado */
                margin-right: auto; /* Centrado */
                padding-bottom: 10px; /* Espacio debajo de la línea */
            }
            /* Estilo para los enlaces dentro de .modelo */
            .modelo a {
                display: inline-block; /* Para que los enlaces se muestren en línea pero se puedan separar */
                margin: 0 25px; /* Separar los enlaces entre sí */
                text-decoration: none;
                color: black;
                font-weight: bold;
                transition: color 0.3s;
            }

            /* Efecto hover sobre los enlaces */
            .modelo a:hover {
                color: rgb(207, 27, 27); /* Cambia el color al pasar el cursor */
            }
            /*Cuerpo*/
            body{
                background-color: #eaeded;
                font-family: Arial, sans-serif;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            /*Barra de navegacion*/
            nav{
                background: #000; 
                width: 100%;/* El tamaño de los largo de la barra negra de conocenos*/
                text-align: center;
                padding: 1.5px 10px; /* Espaciado interno   y  espacio de lo alto de la barra*/
            }
            nav a {
                text-decoration: none;
                color: white;
                margin-bottom: 20%;
                margin: 0 15px;
                padding: 27px;
                font-family: 'Perpetua', sans-serif; /* Cambia la fuente aquí */
                font-size: 28px;
                transition: color 0.3s;

            }
            nav a:hover {
                color: gray; /* Cambia el color al pasar el cursor */
                font-weight: bold;
            }

            /* Catalogo */
            .catalogo{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(370px, 1fr));
                gap: 30px;
                padding: 50px 20px;
                width: 100%;
                max-width: 1200px; /* Limita el ancho del contenido */
                margin: 0 auto; /* Centra el catálogo */
            }
            .autos{
                text-align: center;
                background-color: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                transition: transform 0.3s, box-shadow 0.3s;
                display: flex;
                flex-direction: column; /* Coloca elementos verticalmente */
                align-items: center; /* Alinea elementos horizontalmente */
                justify-content: center; /* Centra verticalmente */
                height: 100%; /* Para asegurar alineación uniforme */
            }
            .autos:hover{
                transform: scale(1.05);
                box-shadow: 0.8px, 12px, rgb(0, 0, 0, 0.2);
            }
            .autos img{
                width: auto; /* Evita que se distorsione */
                max-width: 90%; /* Ajusta al contenedor */
                max-height: 200px; /* Limita la altura */
                margin: 0 auto 15px auto; /* Centra la imagen horizontalmente */
                border-radius: 8px;
                cursor: pointer;
            }
            .nombre{
                font-size: 21px;
                font-weight: bold;
                margin: 10px 0;
            }

        </style>
    </head>
    <body>
        <header>
            <img src="Imagenes/Logo.jpg" alt="Logo" class="logo">
       
            <div class="sesion">
               <a href="Admin.html">Inicio de Sesion</a>
           </div>
        </header>       
            <nav>
               <center>
                   <ul class="inpinios">
                       <a href="index.html">Nuestra Historia</a>
                       <a href="DCatalogo.php">Catalogo</a>
                       <a href="Acerca.html">Acerca de nosotros</a>
                       <a href="RAgenedarCita.php">Agendar Cita</a>
                   </ul>
               </center>
           </nav>

<!-- Menu de autos, suvs, roadsters -->
<div class="Modelo">
            <ul>
               <a href="DCatalogo.PHP">Autos</a>
               <a href="DSuvs.php">Suvs</a>
               <a href="DRoadsters.php">Roadsters</a>
            </ul>
       </div>


        <!-- Menu de autos, suvs, roadsters -->
        <div class="catalogo">

    <?php
    include("Controlador.php");
    $Con = Conectar();

    // Consulta para obtener los vehículos de la categoría "Autos"
    $Categoria='Roadsters';
    $SQL = "SELECT * FROM Inventario WHERE Categoria = '$Categoria'";
    $ResultSet = mysqli_query($Con, $SQL);

    if (mysqli_num_rows($ResultSet) > 0) {
        while ($row = mysqli_fetch_assoc($ResultSet)) {
            ?>
            <div class="autos">
                <!-- Mostrar la imagen del vehículo -->
                <img src="<?php echo $row['Imagen_Vehiculo']; ?>" alt="<?php echo $row['Modelo']; ?>" 
                     onclick="window.location.href='InformacionAutos.php?id=<?php echo $row['Id_Vehiculo']; ?>'">

                <!-- Mostrar el modelo del vehículo -->
                <p class="nombre"><?php echo $row['Modelo']; ?></p>

                <!-- Mostrar el precio -->
                <p class="nombre">Precio $<?php echo number_format($row['Precio'], 2); ?></p>

                <!-- Mostrar el estado -->
                <p class="nombre">ESTADO: <?php echo $row['Estado']; ?></p>

                <!-- Botón de compra -->
                <button class="BotonCompra" onclick="window.location.href='RClientes.php?id=<?php echo $row['Id_Vehiculo']; ?>'"?>Comprar ahora</button>
            </div>
            <?php
        }
    } else {
        echo "<p>No hay vehículos disponibles en la categoría 'Autos'.</p>";
    }
    ?>
</div>