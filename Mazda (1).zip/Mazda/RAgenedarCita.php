<!DOCTYPE html>
<html lang="es">
<head>
    <title>Registro</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="CSS/estilos.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        a {
            text-decoration: none;
            color: white;
            margin-bottom: 20px;
            display: inline-block;
            background-color: #007BFF;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .Formulario {
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .Formulario h2 {
            text-align: center;
            color: #333333;
            margin-bottom: 20px;
        }

        .Formulario input,
        .Formulario select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .Formulario input[type="submit"] {
            background-color: #007BFF;
            color: #ffffff;
            border: none;
            cursor: pointer;
        }

        .Formulario input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
   
    <div class="Formulario">
        <form action="PCitas.php" method="POST">
            <h2>Agenda tu Cita</h2>
            <input type="text" id="Nombre" name="Nombre" placeholder="Nombre" required>
            <input type="text" id="Primer_Apellido" name="Primer_Apellido" placeholder="Primer Apellido" required>
            <input type="text" id="Segundo_Apellido" name="Segundo_Apellido" placeholder="Segundo Apellido" required>
            <input type="text" id="Telefono" name="Telefono" placeholder="Teléfono" required>
            <input type="email" id="Correo" name="Correo" placeholder="Correo Electrónico">
            <select name="Modelo" required>
                <option value="" disabled selected>Selecciona Modelo</option>
                <?php
                    include("Controlador.php"); // Asegúrate de incluir tu archivo de conexión aquí
                    $Con = Conectar();
                    $SQL = "SELECT Modelo FROM Inventario";
                    $ResultSet = mysqli_query($Con, $SQL);
                    while ($row = mysqli_fetch_array($ResultSet)) {
                        echo "<option value='" . $row['Modelo'] . "'>" . $row['Modelo'] . "</option>";
                    }
                    mysqli_close($Con); // Cerrar conexión después de usarla
                ?>
            </select>
            <input type="date" id="Fecha" name="Fecha" required>
            <input type="time" id="Hora" name="Hora" required>
            <input type="submit" name="enviar" value="Enviar">
        </form>
    </div>
</body>
</html>

