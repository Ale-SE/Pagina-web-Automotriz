<?php
include("Controlador.php");

$Usuario = $_POST['UserName'];
$PW = $_POST['Pw'];

$Con = Conectar();

// Obtener datos del usuario
$SQL = "SELECT  * FROM adminitradores WHERE Username = '$Usuario';";
$ResultSet = Ejecutar($Con, $SQL);
$NoFilas = mysqli_num_rows($ResultSet);

if($NoFilas == 1) {
    // Obtener la fila de resultados
    $DatosCuenta = mysqli_fetch_row($ResultSet);
    $passwordDB = $DatosCuenta[1];
    $intentos = $DatosCuenta[3];
    $bloqueado = $DatosCuenta[2];

    // Verificar si la cuenta está bloqueada
    if ($bloqueado == 1) {
        print("Cuenta bloqueada");
    } else {
        // Comprobar la contraseña
        if ($PW == $passwordDB) {
            // Redirigir al usuario a administradores.html si el acceso es exitoso
            header("Location: Administradores.html");
            exit(); // Terminar el script para que no se ejecute más código

            // Reiniciar intentos a 0 en caso de acceso exitoso
            $SQLResetIntentos = "UPDATE adminitradores SET Intento = 0 WHERE Username = '$Usuario';";
            Ejecutar($Con, $SQLResetIntentos);
        } else {
            // Contraseña incorrecta, incrementar intentos
            $intentos++;
            $SQLUpdateIntentos = "UPDATE adminitradores SET Intento = $intentos WHERE Username = '$Usuario';";
            Ejecutar($Con, $SQLUpdateIntentos);

            if ($intentos >= 3) {
                // Bloquear cuenta después de 3 intentos fallidos
                $SQLBlockAccount = "UPDATE adminitradores SET Bloqueado = 1 WHERE Username = '$Usuario';";
                Ejecutar($Con, $SQLBlockAccount);
                print("CUENTA BLOQUEADA POR EXCESO DE INTENTOS");
            } else {
                print("Contraseña incorrecta. Intento $intentos de 3.");
            }
        }
    }
} else {
    print("Usuario no encontrado");
}
?>
