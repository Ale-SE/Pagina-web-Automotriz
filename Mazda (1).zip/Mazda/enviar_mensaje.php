<?php
if (isset($_GET['mensaje'])) {
    $mensaje = htmlspecialchars($_GET['mensaje']);

    // Configurar correo
    $destinatario = "ricoguerreroalondramonserrat@gmail.com"; // Cambia esto por tu correo
    $asunto = "Nuevo mensaje del chat";
    $contenido = "Mensaje del usuario:\n\n" . $mensaje;

    // Enviar correo
    if (mail($destinatario, $asunto, $contenido)) {
        echo "<script>
                alert('Mensaje enviado exitosamente.');
                window.history.back();
              </script>";
    } else {
        echo "<script>
                alert('Hubo un error al enviar tu mensaje.');
                window.history.back();
              </script>";
    }
} else {
    echo "No se recibió ningún mensaje.";
}
?>
