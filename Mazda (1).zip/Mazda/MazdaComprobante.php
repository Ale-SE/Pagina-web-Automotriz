<?php
require('fpdf.php');
include("Controlador.php");

// Conexión a la base de datos
$Con = Conectar();

// Consultar los datos del cliente directamente desde la base de datos
// Suponiendo que ya tienes los datos del cliente guardados en la base de datos
// (puedes ajustar la consulta para obtener los datos de cualquier cliente registrado)
$SQL = "SELECT * FROM Clientes ORDER BY Id_Cliente DESC LIMIT 1"; // Obtener el último cliente registrado
$ResultSet = Ejecutar($Con, $SQL);
$cliente = mysqli_fetch_assoc($ResultSet);

// Consultar el precio del modelo desde Inventarios
$Modelo = $cliente['Modelo'];
$SQL = "SELECT Precio FROM Inventario WHERE Modelo = '$Modelo'";
$ResultSet = Ejecutar($Con, $SQL);
$inventario = mysqli_fetch_assoc($ResultSet);
$Precio = $inventario['Precio'];

// Crear el PDF
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();

// Encabezado
$pdf->Image('Imagenes/logoMazda.png', 8, 8, 35);
$pdf->SetFont('Helvetica', 'B', 22);
$pdf->Cell(280, 10, 'ORDEN DE COMPRA', 0, 1, 'C'); // Ajustar ancho a 280
$pdf->SetXY(240, 10); // Ajustar posición
$pdf->SetFont('Helvetica', 'B', 14);
$pdf->SetTextColor(255, 255, 255); // Texto blanco
$pdf->SetFillColor(255, 0, 0); // Fondo rojo
$pdf->Cell(50, 10, 'No. Folio: ' . $cliente['Id_Cliente'], 1, 1, 'C', true); // Celda bordeada y con fondo
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', 'B', 18);
$pdf->SetY(23);
$pdf->Cell(0, 10, 'MAZDA', 0, 1, 'C');
$pdf->Ln(5);

// Información del CLIENTE
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetFillColor(220, 220, 220);
$pdf->Cell(50, 10, 'Datos del Cliente', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(55, 10, 'NOMBRE: ', 1, 0);
$pdf->Cell(80, 10, $cliente['Nombre'], 1, 1);
$pdf->Cell(55, 10, 'APELLIDO PATERNO: ', 1, 0);
$pdf->Cell(80, 10, $cliente['Primer_Apellido'], 1, 1);
$pdf->Cell(55, 10, 'APELLIDO MATERNO: ', 1, 0);
$pdf->Cell(80, 10, $cliente['Segundo_Apellido'], 1, 1);
$pdf->Cell(55, 10, 'NUMERO DEL TELEFONO: ', 1, 0);
$pdf->Cell(80, 10, $cliente['Telefono'], 1, 1);
$pdf->Cell(55, 10, 'CORREO ELECTRONICO: ', 1, 0);
$pdf->Cell(80, 10, $cliente['Correo'], 1, 1);
$pdf->Ln(5);

// Información del AUTO
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetY(38);
$pdf->Cell(0, 10, 'Datos del Auto', 0, 1, 'R');
$pdf->SetFont('Arial', '', 11);
$pdf->SetXY(173, 48);
$pdf->Cell(45, 10, 'MODELO DEL AUTO: ', 1, 0);
$pdf->Cell(70, 10, $cliente['Modelo'], 1, 1);
$pdf->SetXY(173, 58);
$pdf->Cell(45, 10, 'PRECIO: ', 1, 0);
$pdf->Cell(70, 10, '$ ' . $Precio, 1, 1);
$pdf->Ln(5);

// Texto después de la tabla
$pdf->SetY(105);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Presentate en las instalaciones MAZDA ', 0, 1, 'C');
$pdf->SetY(115);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'El dia   ' . $cliente['Fecha'] . '   a las  ' . $cliente['Hora'], 0, 1, 'C');


// Autorizado y Recibido
$pdf->SetY(150);
$pdf->Cell(170, 10, 'Autorizado por: ', 0, 1, 'L');
$pdf->SetXY(170, 150);
$pdf->Cell(170, 10, 'Recibido por: ', 0, 1);

// Pies de pagina IMAGENES
$pdf->Image('Imagenes/auto.jpeg', 230, 170, 50, 40);
$pdf->Image('Imagenes/firma2.jpeg', 50, 140, 30, 30);

// Salida del PDF
$pdf->Output();
?>
