<?php 
    include("Controlador.php");

    $Con = Conectar();

    $Username = $_POST['Username'];
    $PW = $_POST['PW'];

    // Corregir la consulta SQL con el punto y coma
    $SQL = "INSERT INTO adminitradores (Username, PW) 
    VALUES ('$Username', '$PW');";


    // Ejecutar la consulta
    $ResultSet = Ejecutar($Con, $SQL);

    if ($ResultSet) {
     print("Registro Existoso");
        // header("Location: RegistroCitas.html");
          
    } else {
        print("Error: " . mysqli_error($Con));
    }

    // Cerrar la conexión
    mysqli_close($Con);
?>