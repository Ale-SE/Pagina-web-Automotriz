<?php
// Conectar a la base de datos
include("Controlador.php");
$Con = Conectar();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Administradores</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
        }
        table td, table th {
            border: 1px solid black;
            text-align: center;
            padding: 5px;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            box-sizing: border-box;
            text-align: center;
        }
        .search-bar {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .search-bar input[type="text"] {
            width: 200px;
            padding: 5px;
            font-size: 14px;
        }

        .search-bar button {
            padding: 5px 10px;
            font-size: 14px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 3px;
        }

        .search-bar button:hover {
            background-color: #0056b3;
        }

        button[name="reset"] {
            background-color: #f0f0f0;
            color: #000;
            border: 1px solid #ccc;
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <header>
        <img src="Imagenes/Logo.jpg" alt="Logo">
        <div class="Foto">
            <a href="index.html"><img src="Imagenes/home2.png" alt="home" width="90px" height="60px"></a>
        </div>
    </header>

    <nav>
        <center>
            <ul>
                <a href="PTablasCitas.php">Citas</a>
                <a href="PTablasClientes.php">Clientes</a>
                <a href="PTablasInventario.php">Inventario</a>
            </ul>
        </center>
    </nav>

    <br>
    <center>
        <a href="RegistroAdmin.html"><img src="Imagenes/mas.png" alt="mas" width="70px" height="50px" style="float: right; margin-right: 20px;"></a>
        <h2>Registro de Vehículos</h2>
        <br><br>

        <!-- Barra de búsqueda -->
        <form method="POST" action="BusquedaInventario.php" class="search-bar">
            <input type="text" name="Id_Vehiculo" placeholder="Buscar">
            <button type="submit">Buscar</button>
            <button type="submit" name="reset" value="true">Mostrar todos</button>
        </form>
        <br>
        
        <br>
        
        <!-- Formulario para insertar un nuevo registro -->
        <form method="POST" action="procesarInventario.php" enctype="multipart/form-data" style="margin-bottom: 20px;">
            <input type="hidden" name="new" value="1">
            <table>
                <tr>
                    <td><input type="number" name="Id_Vehiculo" placeholder="ID Vehículo" required></td>
                    <td><input type="file" name="Imagen_Vehiculo" accept="image/*" required></td>
                    <td><input type="text" name="Modelo" placeholder="Modelo" required></td>
                    <td>
                        <select name="Categoria" required>
                            <option value="" disabled selected>Selecciona la Categoria</option>
                            <option value="Autos">Autos</option>
                            <option value="Suvs">Suvs</option>
                            <option value="Roadsters">Roadsters</option>
                        </select>
                    </td>
                    <td>
                        <select name="Estado" required>
                            <option value="" disabled selected>Selecciona Estado</option>
                            <option value="Disponible">Disponible</option>
                            <option value="Taller">Taller</option>
                            <option value="Vendido">Vendido</option>
                        </select>
                    </td>
                    <td><input type="text" name="Motivo" placeholder="Motivo" required></td>
                    <td><input type="number" name="Precio" placeholder="Precio" step="0.01" min="0" required></td>
                    <td><button type="submit">Agregar</button></td>
                </tr>
            </table>
        </form>
    </center>

<?php
 

// Procesar edición
if (isset($_POST['edit'])) {
    // Validar que el ID del vehículo esté definido en el formulario
    if (!isset($_POST['Id_Vehiculo']) || empty($_POST['Id_Vehiculo'])) {
        echo "<script>alert('El ID del vehículo no se recibió. Por favor, intenta de nuevo.');</script>";
        exit;
    }


    // Capturar los datos enviados por el formulario
    $Id_Vehiculo = intval($_POST['Id_Vehiculo']); // Convertir a entero por seguridad
    $Modelo = $_POST['Modelo'];
    $Categoria = $_POST['Categoria'];
    $Estado = $_POST['Estado'];
    $Motivo = $_POST['Motivo'];
    $Precio = floatval($_POST['Precio']); // Convertir a número decimal

    // Consulta SQL para actualizar el registro
    $SQL = "UPDATE Inventario 
            SET Modelo='$Modelo', 
                Categoria='$Categoria', 
                Estado='$Estado', 
                Motivo='$Motivo', 
                Precio=$Precio 
            WHERE Id_Vehiculo=$Id_Vehiculo";

    $ResultSet = Ejecutar($Con, $SQL); // Ejecutar la consulta

    // Validar el resultado de la actualización
    if ($ResultSet) {
        echo "<script>alert('Registro actualizado con éxito');</script>";
        echo "<script>window.location.href='PTablasInventario.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar el registro');</script>";
    }
}

    // Eliminar un registro
    if (isset($_GET['delete'])) {
        $Id_Vehiculo = $_GET['delete'];
        $SQL = "DELETE FROM Inventario WHERE Id_Vehiculo = $Id_Vehiculo";
        $ResultSet = Ejecutar($Con, $SQL);

        if ($ResultSet) {
            echo "<script>alert('Vehículo eliminado con éxito');</script>";
        } else {
            echo "<script>alert('Error al eliminar el vehículo');</script>";
        }
    }

// Obtener datos de la tabla para mostrarlos en la página
$SQL = "SELECT * FROM Inventario";
$ResultSet = Ejecutar($Con, $SQL);

// Verificar si hay un ID de edición
$editId = isset($_GET['edit']) ? intval($_GET['edit']) : null;

// Mostrar los datos en una tabla
echo '<center>';
echo '<table border="1">';
echo '<tr>';
echo '<th>ID Vehículo</th>';
echo '<th>Imagen</th>';
echo '<th>Modelo</th>';
echo '<th>Categoría</th>';
echo '<th>Estado</th>';
echo '<th>Motivo</th>';
echo '<th>Precio</th>';
echo '<th>Acciones</th>';
echo '</tr>';

// Recorrer los datos y mostrarlos
while ($mostrar = mysqli_fetch_array($ResultSet)) {
    echo '<tr>';

    // Si se está editando un registro, mostrar un formulario en la fila correspondiente
    if ($editId == $mostrar['Id_Vehiculo']) {
        echo '<form method="POST">';
        echo '<td>' . $mostrar['Id_Vehiculo'] . '<input type="hidden" name="Id_Vehiculo" value="' . $mostrar['Id_Vehiculo'] . '"></td>';
        echo '<td><img src="' . $mostrar['Imagen_Vehiculo'] . '" width="100" height="auto"></td>';
        echo '<td><input type="text" name="Modelo" value="' . $mostrar['Modelo'] . '"></td>';
        echo '<td>';
        echo '<select name="Categoria">';
        echo '<option value="Autos"' . ($mostrar['Categoria'] == "Autos" ? " selected" : "") . '>Autos</option>';
        echo '<option value="Suvs"' . ($mostrar['Categoria'] == "Suvs" ? " selected" : "") . '>Suvs</option>';
        echo '<option value="Roadsters"' . ($mostrar['Categoria'] == "Roadsters" ? " selected" : "") . '>Roadsters</option>';
        echo '</select>';
        echo '</td>';
        echo '<td>';
        echo '<select name="Estado">';
        echo '<option value="Disponible"' . ($mostrar['Estado'] == "Disponible" ? " selected" : "") . '>Disponible</option>';
        echo '<option value="Taller"' . ($mostrar['Estado'] == "Taller" ? " selected" : "") . '>Taller</option>';
        echo '<option value="Vendido"' . ($mostrar['Estado'] == "Vendido" ? " selected" : "") . '>Vendido</option>';
        echo '</select>';
        echo '</td>';
        echo '<td><input type="text" name="Motivo" value="' . $mostrar['Motivo'] . '"></td>';
        echo '<td><input type="number" step="0.01" name="Precio" value="' . $mostrar['Precio'] . '"></td>';
        echo '<td>';
        echo '<button type="submit" name="edit">Guardar</button>';
        echo '<a href="PTablasInventario.php">Cancelar</a>';
        echo '</td>';
        echo '</form>';
    } else {
        // Mostrar los datos como texto si no se está editando
        echo '<td>' . $mostrar['Id_Vehiculo'] . '</td>';
        echo '<td><img src="' . $mostrar['Imagen_Vehiculo'] . '" width="100" height="auto"></td>';
        echo '<td>' . $mostrar['Modelo'] . '</td>';
        echo '<td>' . $mostrar['Categoria'] . '</td>';
        echo '<td>' . $mostrar['Estado'] . '</td>';
        echo '<td>' . $mostrar['Motivo'] . '</td>';
        echo '<td>' . $mostrar['Precio'] . '</td>';
        echo '<td>';
        echo '<a href="PTablasInventario.php?edit=' . $mostrar['Id_Vehiculo'] . '">Editar</a>';
        echo '<a href="PTablasInventario.php?delete=' . $mostrar['Id_Vehiculo'] . '" onclick="return confirm(\'¿Está seguro de eliminar este vehículo?\')">Eliminar</a>';
        echo '</td>';
       
    }

    echo '</tr>';
}

echo '</table>';
echo '</center>';
?>


</body>
</html>


