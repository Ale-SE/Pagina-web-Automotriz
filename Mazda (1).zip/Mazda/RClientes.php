<!DOCTYPE html>
<html lang="es">
<head>
    <title>Registro</title>
    <meta charset="UTF-8">
    <style>
        /* General */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: 80%;
            max-width: 1200px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px 40px;
        }

        h1 {
            text-align: center;
            font-size: 1.8rem;
            color: #444;
            margin-bottom: 20px;
        }

        /* Formulario */
        .form {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .form-section {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .form-section:nth-child(2) {
            margin-left: 20px; /* Agrega espacio a la izquierda para los datos adicionales */
        }

        h2 {
            font-size: 1.2rem;
            margin-bottom: 15px;
            color: #555;
        }

        label {
            font-size: 0.9rem;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input,
        select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 0.9rem;
            width: 100%;
        }

        input::placeholder {
            color: #aaa;
        }

        .btn-submit {
            padding: 10px 20px;
            background-color: #d32f2f;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-submit:hover {
            background-color: #a02525;
        }

        /* Responsivo */
        @media (max-width: 768px) {
            .form {
                flex-direction: column;
            }

            .form-section:nth-child(2) {
                margin-left: 0; /* Quitar margen en pantallas pequeñas */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registro de Cliente</h1>
        <form action="PClientes.php" method="POST" class="form">
            <!-- Sección Izquierda: Datos del Usuario -->
            <div class="form-section">
                <h2>Tus Datos</h2>
                <label for="Nombre">Nombre*</label>
                <input type="text" id="Nombre" name="Nombre" placeholder="Nombre" required>

                <label for="Primer_Apellido">Primer Apellido*</label>
                <input type="text" id="Primer_Apellido" name="Primer_Apellido" placeholder="Primer Apellido" required>

                <label for="Segundo_Apellido">Segundo Apellido*</label>
                <input type="text" id="Segundo_Apellido" name="Segundo_Apellido" placeholder="Segundo Apellido" required>

                <label for="Telefono">Teléfono*</label>
                <input type="text" id="Telefono" name="Telefono" placeholder="Teléfono" required>

                <label for="Correo">Correo Electrónico*</label>
                <input type="email" id="Correo" name="Correo" placeholder="Correo Electrónico" required>
            </div>

            <!-- Sección Derecha: Detalles Adicionales -->
            <div class="form-section">
                <h2>Detalles Adicionales</h2>
                <label for="Modelo">Distribuidor*</label>
                <select name="Modelo" id="Modelo" required>
                    <option value="" disabled selected>Selecciona Modelo</option>
                    <?php
                        include("Controlador.php"); // Asegúrate de incluir tu archivo de conexión aquí
                        $Con = Conectar();
                        $SQL = "SELECT Modelo FROM Inventario";
                        $ResultSet = mysqli_query($Con, $SQL);
                        while ($row = mysqli_fetch_array($ResultSet)) {
                            echo "<option value='" . $row['Modelo'] . "'>" . $row['Modelo'] . "</option>";
                        }
                        mysqli_close($Con);
                    ?>
                </select>

                <label for="Fecha">Fecha para recoger*</label>
                <input type="date" id="Fecha" name="Fecha" required>

                <label for="Hora">Hora*</label>
                <input type="time" id="Hora" name="Hora" required>

                <button type="submit" class="btn-submit">Enviar</button>
            </div>
        </form>
    </div>
</body>
</html>
