<?php
include("Controlador.php");
$Con = Conectar();

    $Id_Vehiculo = $_POST['Id_Vehiculo'];
    $SQL = "SELECT * FROM Inventario WHERE Id_Vehiculo ='$Id_Vehiculo';";
    $ResultSet = Ejecutar($Con, $SQL);
    $Fila = mysqli_fetch_row($ResultSet);
    Desconectar($Con);

    echo '<center>';
    echo '<table border="1">';
    echo '<tr>';
    echo '<th>ID Vehículo</th>';
    echo '<th>Imagen</th>';
    echo '<th>Modelo</th>';
    echo '<th>Categoría</th>';
    echo '<th>Estado</th>';
    echo '<th>Motivo</th>';
    echo '<th>Precio</th>';
    echo '</tr>';

    echo '<tr>';
    echo '<td>' . $Fila['0'] . '</td>';
    echo '<td><img src="' . $Fila['1'] . '" alt="Imagen del vehículo" style="width:100px;height:auto;"></td>';
    echo '<td>' . $Fila[2] . '</td>';
    echo '<td>' . $Fila[3] . '</td>';
    echo '<td>' . $Fila[4] . '</td>';
    echo '<td>' . $Fila[5] . '</td>';
    echo '<td>' . $Fila[6] . '</td>';
    echo '</tr>';
    


exit();
?>
