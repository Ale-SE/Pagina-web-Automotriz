<?php
// Verifica si el formulario fue enviado con POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Recoger los datos del formulario
    $Nombre = $_POST['Nombre'];
    $Primer_Apellido = $_POST['Primer_Apellido'];
    $Segundo_Apellido = $_POST['Segundo_Apellido'];
    $Telefono = $_POST['Telefono'];
    $Correo = $_POST['Correo'];
    $Modelo = $_POST['Modelo'];
    $Fecha = $_POST['Fecha'];
    $Hora = $_POST['Hora'];

    // Incluir el archivo de conexión a la base de datos
    include("Controlador.php");

    // Conectar a la base de datos
    $Con = Conectar();

    // Crear la consulta SQL para insertar los datos en la tabla Clientes
    $SQL = "INSERT INTO Citas (Nombre, Primer_Apellido, Segundo_Apellido, Telefono, Correo, Modelo, Fecha, Hora) 
            VALUES ('$Nombre', '$Primer_Apellido', '$Segundo_Apellido', '$Telefono', '$Correo', '$Modelo', '$Fecha', '$Hora')";

    // Ejecutar la consulta
    if (mysqli_query($Con, $SQL)) {
        echo "Cita registrada con éxito.";
    } else {
        echo "Error: " . mysqli_error($Con);
    }

    // Cerrar la conexión
    mysqli_close($Con);
}
?>
