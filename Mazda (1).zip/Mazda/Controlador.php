<?php 

	function Conectar(){
		$User="root";
		$Server="127.0.0.1";
		$Pwd="";
		$BD="Mazda";
		$Con = mysqli_connect($Server,$User,$Pwd,$BD);
		return $Con;
	}

	function Ejecutar($Con,$SQL){
		$ResultSet = mysqli_query($Con,$SQL);
		return $ResultSet;
	}

	function Prosesar(){

	}

	function Desconectar($Con){
		$Valor = mysqli_close($Con);
		return $Valor;
	}
	
 ?>