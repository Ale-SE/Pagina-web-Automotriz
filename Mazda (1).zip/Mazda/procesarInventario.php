<?php
include("Controlador.php");
$Con = Conectar();

if (isset($_POST['new']) && $_POST['new'] == 1) {
    // Recibir datos del formulario
    $Id_Vehiculo = $_POST['Id_Vehiculo']; // Nuevo campo
    $Modelo = $_POST['Modelo'];
    $Categoria=$_POST['Categoria'];
    $Estado = $_POST['Estado'];
    $Motivo = $_POST['Motivo'];
    $Precio = $_POST['Precio'];

    // Verificar si se subió una imagen
    if (isset($_FILES['Imagen_Vehiculo']) && $_FILES['Imagen_Vehiculo']['error'] == 0) {
        $Imagen_Vehiculo = $_FILES['Imagen_Vehiculo']['name'];
        $Imagen_Vehiculo_tmp = $_FILES['Imagen_Vehiculo']['tmp_name'];

        // Mover la imagen a la carpeta 'uploads'
        $Ruta_Imagen = "uploads/" . basename($Imagen_Vehiculo);
        move_uploaded_file($Imagen_Vehiculo_tmp, $Ruta_Imagen);

        // Insertar los datos en la base de datos
        $SQL = "INSERT INTO Inventario (Id_Vehiculo, Imagen_Vehiculo, Modelo, Categoria, Estado, Motivo, Precio) 
                VALUES ('$Id_Vehiculo', '$Ruta_Imagen', '$Modelo', '$Categoria', '$Estado', '$Motivo', '$Precio')";
        mysqli_query($Con, $SQL);
    }
}

// Redirigir a la página de inventario
header("Location: PTablasInventario.php");
exit();
?>
