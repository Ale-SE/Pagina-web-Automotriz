<?php
// Conectar a la base de datos
include("Controlador.php");
$Con = Conectar();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Administradores</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
        }
        table td, table th {
            border: 1px solid black;
            text-align: center;
            padding: 5px;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            box-sizing: border-box;
            text-align: center;
        }
        .search-bar {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .search-bar input[type="text"] {
            width: 200px;
            padding: 5px;
            font-size: 14px;
        }

        .search-bar button {
            padding: 5px 10px;
            font-size: 14px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 3px;
        }

        .search-bar button:hover {
            background-color: #0056b3;
        }

        button[name="reset"] {
            background-color: #f0f0f0;
            color: #000;
            border: 1px solid #ccc;
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <header>
        <img src="Imagenes/Logo.jpg" alt="Logo">
        <div class="Foto">
            <a href="index.html"><img src="Imagenes/home2.png" alt="home" width="90px" height="60px"></a>
        </div>
    </header>

    <nav>
        <center>
            <ul>
                <a href="PTablasCitas.php">Citas</a>
                <a href="PTablasClientes.php">Clientes</a>
                <a href="PTablasInventario.php">Inventario</a>
            </ul>
        </center>
    </nav>

    <br>
    <center>
        <a href="RegistroAdmin.html"><img src="Imagenes/mas.png" alt="mas" width="70px" height="50px" style="float: right; margin-right: 20px;"></a>
        <h2>Registro de Clientes</h2>
        <br><br>

        <!-- Barra de búsqueda -->
        <form method="GET" action="PTablasClientes.php" class="search-bar">
            <input type="text" name="search" placeholder="Buscar por Nombre o Teléfono" autocomplete="off" 
                   value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
            <button type="submit">Buscar</button>
            <button type="submit" name="reset" value="true">Mostrar todos</button>
        </form>
        <br>
        
        <!-- Formulario para insertar un nuevo registro -->
        <form method="POST" style="margin-bottom: 20px;">
            <input type="hidden" name="new" value="1">
            <table>
                <tr>
                    <td><input type="text" name="Nombre" placeholder="Nombre" required></td>
                    <td><input type="text" name="Primer_Apellido" placeholder="Primer Apellido" required></td>
                    <td><input type="text" name="Segundo_Apellido" placeholder="Segundo Apellido" required></td>
                    <td><input type="text" name="Telefono" placeholder="Numero de Teléfono" maxlength="15" required></td>
                    <td><input type="email" name="Correo" placeholder="Correo Electrónico" required></td>
                    <td>
                        <select name="Modelo" required>
                            <option value="" disabled selected>Selecciona Modelo</option>
                            <?php
                                // Traer los modelos de la tabla Inventario
                                $SQL = "SELECT Modelo FROM Inventario";
                                $ResultSet = Ejecutar($Con, $SQL);
                                while ($row = mysqli_fetch_array($ResultSet)) {
                                    echo "<option value='" . $row['Modelo'] . "'>" . $row['Modelo'] . "</option>";
                                }
                            ?>
                        </select>
                    </td>
                    <td><input type="date" name="Fecha" required></td>
                    <td><input type="time" name="Hora" required></td>
                    <td><button type="submit">Agregar</button></td>
                </tr>
            </table>
        </form>
    </center>

    <?php
    // Procesar inserción de nuevo registro
    if (isset($_POST['new']) && $_POST['new'] == 1) {
        $Nombre = $_POST['Nombre'];
        $Primer_Apellido = $_POST['Primer_Apellido'];
        $Segundo_Apellido = $_POST['Segundo_Apellido'];
        $Telefono = $_POST['Telefono'];
        $Correo = $_POST['Correo'];
        $Modelo = $_POST['Modelo'];
        $Fecha = $_POST['Fecha'];
        $Hora = $_POST['Hora'];

        // Mostrar los valores antes de la inserción (depuración)
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";

        // Inserción de datos en la tabla Clientes
        $SQL = "INSERT INTO Clientes (Nombre, Primer_Apellido, Segundo_Apellido, Telefono, Correo, Modelo, Fecha, Hora) 
                VALUES ('$Nombre', '$Primer_Apellido', '$Segundo_Apellido', '$Telefono', '$Correo', '$Modelo', '$Fecha', '$Hora')";

        $ResultSet = Ejecutar($Con, $SQL);

        if ($ResultSet) {
            echo "<script>alert('Cliente registrada con éxito');</script>";
            echo "<script>window.location.href='PTablasClientes.php';</script>";
        } else {
            echo "<script>alert('Error al insertar la Registro: " . mysqli_error($Con) . "');</script>";
        }
    }

    // Procesar búsqueda y mostrar todos
    $whereClause = "";
    if (isset($_GET['search']) && !empty($_GET['search']) && !isset($_GET['reset'])) {
        $searchTerm = mysqli_real_escape_string($Con, $_GET['search']);
        $whereClause = "WHERE Nombre LIKE '%$searchTerm%' OR Telefono LIKE '%$searchTerm%'";
    }

     // Procesar edición
     if (isset($_POST['edit'])) {
        $Id_Cliente=$_POST['Id_Cliente'];
        $Nombre = $_POST['Nombre'];
        $Primer_Apellido = $_POST['Primer_Apellido'];
        $Segundo_Apellido = $_POST['Segundo_Apellido'];
        $Telefono = $_POST['Telefono'];
        $Correo = $_POST['Correo'];
        $Modelo = $_POST['Modelo'];
        $Fecha = $_POST['Fecha'];
        $Hora = $_POST['Hora'];

        $SQL = "UPDATE Clientes SET Nombre='$Nombre', Primer_Apellido='$Primer_Apellido', Segundo_Apellido='$Segundo_Apellido', 
        Telefono='$Telefono', Telefono='$Telefono', Correo='$Correo', Modelo='$Modelo', Fecha='$Fecha',
        Hora='$Hora' WHERE Id_Cliente=$Id_Cliente";
        
        $ResultSet=Ejecutar($Con, $SQL);

        if ($ResultSet) {
            echo "<script>alert('Registro actualizado con éxito');</script>";
            echo "<script>window.location.href='PTablasClientes.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar e registro');</script>";
        }
    }

    // Eliminar un registro
    if (isset($_GET['delete'])) {
        $Id_Cliente = $_GET['delete'];
        $SQL = "DELETE FROM Clientes WHERE Id_Cliente = $Id_Cliente";
        $ResultSet = Ejecutar($Con, $SQL);

        if ($ResultSet) {
            echo "<script>alert('Registro eliminado con éxito');</script>";
        } else {
            echo "<script>alert('Error al eliminar Registro');</script>";
        }
    }
    ?>

    <center>
    <table>
        <tr>
            <th>Id_Cliente</th>
            <th>Nombre</th>
            <th>Primer Apellido</th>
            <th>Segundo Apellido</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>Modelo</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Acciones</th>
        </tr>

    <?php
    // Obtener registros (filtrados o no)
    $SQL = "SELECT * FROM Clientes $whereClause";
    $ResultSet = Ejecutar($Con, $SQL);

    if (mysqli_num_rows($ResultSet) == 0) {
        echo "<tr><td colspan='10'>No se encontraron registros.</td></tr>";
    } else {
        $editId = isset($_GET['edit']) ? $_GET['edit'] : null;

        while ($mostrar = mysqli_fetch_array($ResultSet)): ?>
            <tr>
                <?php if ($editId == $mostrar['Id_Cliente']): ?>
                    <!-- Formulario de edición -->
                    <form method="POST">
                        <td><?php echo $mostrar['Id_Cliente']; ?>
                            <input type="hidden" name="Id_Cliente" value="<?php echo $mostrar['Id_Cliente']; ?>">
                        </td>
                        <td><input type="text" name="Nombre" value="<?php echo $mostrar['Nombre']; ?>"></td>
                        <td><input type="text" name="Primer_Apellido" value="<?php echo $mostrar['Primer_Apellido']; ?>"></td>
                        <td><input type="text" name="Segundo_Apellido" value="<?php echo $mostrar['Segundo_Apellido']; ?>"></td>
                        <td><input type="text" name="Telefono" value="<?php echo $mostrar['Telefono']; ?>"></td>
                        <td><input type="email" name="Correo" value="<?php echo $mostrar['Correo']; ?>"></td>
                        <td>
                        <select name="Modelo" required>
                            <option value="" disabled selected>Selecciona Modelo</option>
                            <?php
                                // Traer los modelos de la tabla Inventario
                                $SQL = "SELECT Modelo FROM Inventario";
                                $ResultSet = Ejecutar($Con, $SQL);
                                while ($row = mysqli_fetch_array($ResultSet)) {
                                    echo "<option value='" . $row['Modelo'] . "'>" . $row['Modelo'] . "</option>";
                                }
                            ?>
                        </select>
                        </td>
                        <td><input type="date" name="Fecha" value="<?php echo $mostrar['Fecha']; ?>"></td>
                        <td><input type="time" name="Hora" value="<?php echo $mostrar['Hora']; ?>"></td>
                        <td><button type="submit" name="edit">Actualizar</button></td>
                    </form>
                <?php else: ?>
                    <!-- Mostrar datos -->
                    <td><?php echo $mostrar['Id_Cliente']; ?></td>
                     <td><?php echo $mostrar['Nombre']; ?></td>
                    <td><?php echo $mostrar['Primer_Apellido']; ?></td>
                    <td><?php echo $mostrar['Segundo_Apellido']; ?></td>
                    <td><?php echo $mostrar['Telefono']; ?></td>
                    <td><?php echo $mostrar['Correo']; ?></td>
                    <td><?php echo $mostrar['Modelo']; ?></td>
                    <td><?php echo $mostrar['Fecha']; ?></td>
                    <td><?php echo $mostrar['Hora']; ?></td>
                    <td>
                        <a href="PTablasClientes.php?edit=<?php echo $mostrar['Id_Cliente']; ?>">Editar</a> |
                        <a href="PTablasClientes.php?delete=<?php echo $mostrar['Id_Cliente']; ?>">Eliminar</a>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endwhile; ?>
        <?php } ?>
    </table>
    </center>
</body>
</html>