<?php 
    include("Controlador.php");

    $Con = Conectar();

    $Nombre = $_POST['Nombre'];
    $Primer_Apellido = $_POST['Primer_Apellido'];
    $Segundo_Apellido = $_POST['Segundo_Apellido'];
    $Telefono = $_POST['Telefono'];
    $Correo = $_POST['Correo'];
    $Modelo = $_POST['Modelo'];
    $Fecha= $_POST['Fecha'];
    $Hora = $_POST['Hora'];

    // Corregir la consulta SQL con el punto y coma
    $SQL = "INSERT INTO Clientes (Nombre, Primer_Apellido, Segundo_Apellido, Telefono, Correo, Modelo, Fecha, Hora) 
    VALUES ('$Nombre', '$Primer_Apellido', '$Segundo_Apellido', '$Telefono', '$Correo', '$Modelo', '$Fecha', '$Hora');";


    // Ejecutar la consulta
    $ResultSet = Ejecutar($Con, $SQL);

    if ($ResultSet) {
      header("Location: MazdaComprobante.php");
          
    } else {
        print("Error: " . mysqli_error($Con));
    }

    // Cerrar la conexión
    mysqli_close($Con);
?>