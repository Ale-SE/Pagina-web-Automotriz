<?php
// Incluir archivo para la conexión a la base de datos
include("Controlador.php");

    $Con = Conectar();

// Verificar si el formulario ha sido enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $UserName = $_POST['UserName'];
    $Pw = $_POST['Pw'];

    // Conectar a la base d

    // Consultar si el usuario existe
    $SQL = "SELECT * FROM usuarios WHERE Usuario = '$UserName'";
    $ResultSet = Ejecutar($Con, $SQL);

    // Verificar si el usuario existe
    if ($ResultSet && mysqli_num_rows($ResultSet) > 0) {
        $Fila = mysqli_fetch_assoc($ResultSet);

        // Comparar la contraseña 
        if ($Fila['Contrasenia'] == $Pw) {
            header("Location: RegistroCitas.html");
            exit(); 
        } else {
            // Contraseña incorrecta
            echo "<script>
                    alert('Contraseña incorrecta');
                    window.location.href = 'login.php'; // Volver al formulario de login
                  </script>";
            exit();
        }
    } else {
        // Usuario no encontrado
        echo "<script>
                alert('Usuario no encontrado');
                window.location.href = 'login.php'; // Volver al formulario de login
              </script>";
        exit();
    }

    // Cerrar la conexión a la base de datos
    mysqli_close($Con);
}
?>


